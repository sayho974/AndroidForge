package app.capitalquest.domain

import app.capitalquest.data.CountryEntity
import app.capitalquest.data.ProgressEntity

data class ContinentState(
    val name: String, val total: Int, val completed: Int, val mastered: Int, val unlocked: Boolean,
) { val ratio: Double get() = if (total == 0) 0.0 else completed.toDouble() / total }

object Journey {
    const val UNLOCK_RATIO = 0.8   // finish 80% of a continent's ladders to open the next one

    fun states(countries: List<CountryEntity>, progress: List<ProgressEntity>, unlockAll: Boolean): List<ContinentState> {
        val byCode = progress.associateBy { it.code }
        val out = ArrayList<ContinentState>()
        CONTINENTS.forEachIndexed { i, name ->
            val list = countries.filter { it.continent == name }
            val done = list.count { (byCode[it.code]?.stage ?: 0) >= LADDER_DONE }
            val mastered = list.count { byCode[it.code]?.let { p -> Mastery.of(p) == Mastery.MASTERED } == true }
            val unlocked = unlockAll || i == 0 || out[i - 1].ratio >= UNLOCK_RATIO
            out += ContinentState(name, list.size, done, mastered, unlocked)
        }
        return out
    }

    fun worldUnlocked(states: List<ContinentState>, unlockAll: Boolean) =
        unlockAll || states.all { it.ratio >= UNLOCK_RATIO }
}
