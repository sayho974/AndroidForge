package app.capitalquest.domain

import app.capitalquest.data.ProgressEntity
import kotlin.math.max
import kotlin.math.min

data class SrsState(val ease: Double = 2.3, val intervalDays: Double = 0.0, val reps: Int = 0, val lapses: Int = 0)
data class SrsNext(val state: SrsState, val nextReviewAt: Long)

/** SM-2 style scheduler (pure Kotlin, unit-tested). */
object SrsEngine {
    const val DAY_MS = 86_400_000L
    const val RELEARN_MS = 10 * 60_000L
    const val MAX_INTERVAL = 365.0
    const val SPACED_GAP_MS = 18 * 60 * 60_000L

    /** Answer quality from: correctness, hints used, question type and response time. */
    fun gradeFor(correct: Boolean, hints: Int, type: QType, timeMs: Long): Grade {
        if (!correct) return Grade.AGAIN
        if (hints > 0) return Grade.HARD                      // needed help -> weaker evidence
        val typed = type != QType.MCQ
        val slow = if (typed) 25_000L else 12_000L
        return when {
            timeMs > slow -> Grade.HARD
            typed && timeMs <= 7_000L -> Grade.EASY            // fast, unaided typed recall
            else -> Grade.GOOD
        }
    }

    fun next(s: SrsState, g: Grade, now: Long): SrsNext {
        var ease = s.ease
        var reps = s.reps
        var lapses = s.lapses
        var interval: Double
        when (g) {
            Grade.AGAIN -> {
                ease = max(1.3, ease - 0.20)
                lapses += 1
                return SrsNext(SrsState(ease, 0.0, 0, lapses), now + RELEARN_MS)   // comes back in 10 minutes
            }
            Grade.HARD -> {
                ease = max(1.3, ease - 0.15)
                interval = max(1.0, s.intervalDays * 1.2)
            }
            Grade.GOOD -> {
                reps += 1
                interval = when {
                    reps <= 1 -> 1.0
                    reps == 2 -> 3.0
                    else -> max(s.intervalDays * ease, s.intervalDays + 1)
                }
            }
            Grade.EASY -> {
                reps += 1
                ease = min(3.0, ease + 0.10)
                interval = when {
                    reps <= 1 -> 3.0
                    reps == 2 -> 6.0
                    else -> max(s.intervalDays * ease * 1.3, s.intervalDays + 2)
                }
            }
        }
        // Difficulty: countries that lapsed often grow their interval more slowly.
        interval *= 1.0 - 0.08 * min(lapses, 5)
        interval = interval.coerceIn(1.0, MAX_INTERVAL)
        return SrsNext(SrsState(ease, interval, reps, lapses), now + (interval * DAY_MS).toLong())
    }

    // ---- scheduling helpers used by Review / World Challenge ----

    fun isDue(p: ProgressEntity, now: Long) = p.nextReview in 1..now
    fun isProblem(p: ProgressEntity) = Mastery.of(p) == Mastery.WEAK && (p.correct + p.wrong) > 0

    /** Review pool: due now OR currently a problem. Mastered, not-yet-due countries are NOT included. */
    fun reviewCandidates(all: List<ProgressEntity>, now: Long): List<ProgressEntity> =
        all.filter { it.lastSeen > 0 && (isDue(it, now) || isProblem(it)) }
            .sortedByDescending { priority(it, now) }

    fun priority(p: ProgressEntity, now: Long): Double {
        val attempts = p.correct + p.wrong
        val overdue = if (isDue(p, now)) (now - p.nextReview).toDouble() / DAY_MS / max(1.0, p.intervalDays) else 0.0
        var s = overdue
        if (Mastery.of(p) == Mastery.WEAK) s += 3.0
        s += p.lapses * 0.25
        if (attempts > 0) s += p.wrong.toDouble() / attempts * 2.0
        return s
    }
}
