package app.capitalquest.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.capitalquest.domain.CONTINENTS
import app.capitalquest.domain.continentEmoji
import app.capitalquest.domain.flagEmoji

@Composable
fun HomeScreen(onJourney: () -> Unit, onReview: () -> Unit, onWorld: () -> Unit, onProgress: () -> Unit,
               onSettings: () -> Unit, vm: HomeViewModel = viewModel()) {
    val h by vm.home.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("🌍 Capital Quest", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            TextButton(onClick = onSettings) { Text("⚙️", fontSize = 22.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatChip("🌍", "${h.learned}/${h.total}", "Countries learned", Modifier.weight(1f))
            StatChip("⭐", "${h.xp}", "XP", Modifier.weight(1f))
            StatChip("🔥", "${h.streak}", "Streak", Modifier.weight(1f))
            StatChip("📊", "${h.masteryPercent}%", "Mastery", Modifier.weight(1f))
        }
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("🔥 تحتاج مراجعة الآن: ${h.dueCount} دولة", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (h.problems.isNotEmpty()) Spacer(Modifier.height(6.dp))
                h.problems.forEach {
                    Text("${flagEmoji(it.country.code)} ${it.country.name} — ${it.country.capital}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        BigButton("START JOURNEY", onJourney)
        BigButton("🧠 REVIEW", onReview, enabled = h.dueCount > 0, container = MaterialTheme.colorScheme.secondary,
            content = MaterialTheme.colorScheme.onSecondary)
        BigButton("🌎 WORLD CHALLENGE" + if (h.worldUnlocked) "" else " 🔒", onWorld, enabled = h.worldUnlocked,
            container = MaterialTheme.colorScheme.surfaceVariant, content = MaterialTheme.colorScheme.onSurface)
        BigButton("📊 MY PROGRESS", onProgress, container = MaterialTheme.colorScheme.surfaceVariant,
            content = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun JourneyScreen(onBack: () -> Unit, onStart: (Int) -> Unit, vm: HomeViewModel = viewModel()) {
    val h by vm.home.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
            Text("رحلتك حول العالم", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text("أكمل 80% من دول القارة لفتح التالية.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        h.continents.forEachIndexed { i, c ->
            val ratio by animateFloatAsStateCompat(c.ratio.toFloat())
            Surface(Modifier.fillMaxWidth().clickable(enabled = c.unlocked) { onStart(i) },
                shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(continentEmoji(c.name), fontSize = 30.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("${c.completed}/${c.total} مكتملة · ${c.mastered} متقنة",
                                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                        Text(when { !c.unlocked -> "🔒"; i == h.lastContinent -> "▶ متابعة"; else -> "›" }, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { ratio }, Modifier.fillMaxWidth().height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun animateFloatAsStateCompat(target: Float): State<Float> =
    androidx.compose.animation.core.animateFloatAsState(target, label = "bar")
