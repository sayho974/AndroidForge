package app.capitalquest.domain

import app.capitalquest.data.CountryEntity
import kotlin.random.Random

object QuestionGenerator {

    fun known(all: List<CountryEntity>): Set<String> =
        all.flatMap { it.acceptedNames + it.acceptedCapitals }.map { AnswerMatcher.normalize(it) }.toSet()

    /**
     * @param confusions capitals the user wrongly typed/chose for this country before - they become distractors.
     */
    fun build(c: CountryEntity, requested: QType, all: List<CountryEntity>,
              confusions: List<String> = emptyList(), rnd: Random = Random.Default): Question {
        var type = requested
        // City-states (capital == name) cannot be asked "capital -> country" meaningfully.
        if (type == QType.CAPITAL_TO_COUNTRY &&
            c.acceptedNames.any { n -> c.acceptedCapitals.any { AnswerMatcher.normalize(it) == AnswerMatcher.normalize(n) } }
        ) type = QType.FULL_RECALL

        return when (type) {
            QType.LEARN -> Question(c, type, emptyList(), c.acceptedCapitals, c.capital, "")
            QType.MCQ -> Question(c, type, choices(c, all, confusions, rnd), c.acceptedCapitals, c.capital, "")
            QType.COUNTRY_TO_CAPITAL -> Question(c, type, emptyList(), c.acceptedCapitals, c.capital, Hints.cue(c.capital))
            QType.CAPITAL_TO_COUNTRY -> Question(c, type, emptyList(), c.acceptedNames, c.name, "")
            QType.FULL_RECALL -> Question(c, type, emptyList(), c.acceptedCapitals, c.capital, "")
        }
    }

    /** Plausible distractors: same continent, similar spelling, same first letter, or previously confused. */
    fun choices(c: CountryEntity, all: List<CountryEntity>, confusions: List<String>, rnd: Random): List<String> {
        val correctNorm = c.acceptedCapitals.map { AnswerMatcher.normalize(it) }.toSet()
        val confused = confusions.map { AnswerMatcher.normalize(it) }.toSet()
        val target = AnswerMatcher.normalize(c.capital)
        val scored = all.asSequence()
            .filter { it.code != c.code }
            .filter { AnswerMatcher.normalize(it.capital) !in correctNorm }
            .map { o ->
                val n = AnswerMatcher.normalize(o.capital)
                var s = 0.0
                if (o.continent == c.continent) s += 4.0
                if (n.firstOrNull() == target.firstOrNull()) s += 1.5
                s -= AnswerMatcher.levenshtein(n, target).coerceAtMost(12) * 0.25
                if (n in confused) s += 6.0
                o.capital to s
            }
            .distinctBy { it.first }
            .sortedByDescending { it.second }
            .take(8).map { it.first }.toList()
        val picked = scored.shuffled(rnd).take(3)
        return (picked + c.capital).shuffled(rnd)
    }
}
