package app.capitalquest.domain

import app.capitalquest.data.CountryEntity
import app.capitalquest.data.ProgressEntity

enum class Mastery(val emoji: String, val label: String, val weight: Double) {
    NEW("🔴", "جديدة", 0.0),
    WEAK("🟠", "ضعيفة", 0.15),
    LEARNING("🟡", "تتعلمها", 0.35),
    GOOD("🟢", "جيدة", 0.7),
    MASTERED("🔵", "متقنة", 1.0);

    companion object {
        /** Mastery needs SPACED successes - one correct answer can never make a country mastered. */
        fun of(p: ProgressEntity): Mastery {
            val attempts = p.correct + p.wrong
            return when {
                p.stage == 0 && attempts == 0 -> NEW
                p.lastWasWrong || (p.wrong >= 2 && p.streak < 3) -> WEAK
                p.stage >= 5 && p.spacedSuccesses >= 3 && p.intervalDays >= 14 -> MASTERED
                p.stage >= 5 && p.spacedSuccesses >= 1 && p.intervalDays >= 3 -> GOOD
                else -> LEARNING
            }
        }
    }
}

enum class QType { LEARN, MCQ, COUNTRY_TO_CAPITAL, CAPITAL_TO_COUNTRY, FULL_RECALL }
enum class Grade { AGAIN, HARD, GOOD, EASY }
enum class SessionMode { JOURNEY, REVIEW, WORLD }

val CONTINENTS = listOf("Africa", "Europe", "Asia", "North America", "South America", "Oceania")

fun continentEmoji(c: String) = when (c) {
    "Africa", "Europe" -> "🌍"
    "Asia", "Oceania" -> "🌏"
    else -> "🌎"
}

fun flagEmoji(code: String): String =
    code.uppercase().map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")

/** Journey ladder: the stage a country is at decides the next question type. */
fun typeForStage(stage: Int): QType = when (stage) {
    0 -> QType.LEARN
    1 -> QType.MCQ
    2 -> QType.COUNTRY_TO_CAPITAL
    3 -> QType.CAPITAL_TO_COUNTRY
    else -> QType.FULL_RECALL
}
const val LADDER_DONE = 5

data class Question(
    val country: CountryEntity,
    val type: QType,
    val choices: List<String>,      // MCQ only
    val accepted: List<String>,     // normalised later by the matcher
    val answerDisplay: String,
    val cue: String,                // e.g. "_ _ _ _ _" for cued recall, "" otherwise
)
