package app.capitalquest.domain

import java.text.Normalizer

enum class Match { EXACT, TYPO, WRONG }

object AnswerMatcher {
    private val marks = Regex("\\p{M}+")
    private val nonAlnum = Regex("[^a-z0-9]+")

    fun normalize(s: String): String {
        var t = Normalizer.normalize(s, Normalizer.Form.NFD).replace(marks, "").lowercase()
        t = t.replace(".", "").replace("'", "").replace("’", "").replace("`", "").replace("&", " and ")
        t = t.replace(nonAlnum, " ").trim()
        t = t.replace(Regex("\\bsaint\\b"), "st")
        if (t.startsWith("the ")) t = t.removePrefix("the ")
        return t.replace(Regex("\\s+"), " ")
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + c)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /**
     * @param known normalised names/capitals of ALL countries: typing another real answer
     *              (e.g. "Kingston" for Kingstown) is never forgiven as a typo.
     */
    fun check(input: String, accepted: List<String>, known: Set<String>): Match {
        val n = normalize(input)
        if (n.isEmpty()) return Match.WRONG
        val acc = accepted.map { normalize(it) }
        if (n in acc) return Match.EXACT
        if (n in known) return Match.WRONG
        val best = acc.minOf { levenshtein(n, it) }
        val len = acc.minBy { levenshtein(n, it) }.length
        val tol = when { len >= 12 -> 2; len >= 6 -> 1; else -> 0 }
        return if (best <= tol) Match.TYPO else Match.WRONG
    }
}

object Hints {
    /** 1 = first letter, 2 = letter count pattern, 3 = half of the letters (+ audio in the UI). */
    fun build(answer: String, level: Int): String = when (level) {
        1 -> "يبدأ بالحرف: ${answer.first().uppercaseChar()}"
        2 -> mask(answer, 1)
        else -> mask(answer, (answer.count { it.isLetter() } + 1) / 2)
    }

    private fun mask(answer: String, reveal: Int): String {
        var shown = 0
        return answer.map { c ->
            when {
                !c.isLetter() -> c.toString()
                shown < reveal -> { shown++; c.toString() }
                else -> "_"
            }
        }.joinToString(" ")
    }

    fun cue(answer: String): String = mask(answer, 0)
}
