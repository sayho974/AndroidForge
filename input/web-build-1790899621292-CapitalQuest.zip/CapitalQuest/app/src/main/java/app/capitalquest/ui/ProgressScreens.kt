package app.capitalquest.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.capitalquest.data.AttemptEntity
import app.capitalquest.domain.CONTINENTS
import app.capitalquest.domain.Mastery
import app.capitalquest.domain.flagEmoji

@Composable
fun ProgressScreen(onBack: () -> Unit, vm: ProgressViewModel = viewModel()) {
    val rows by vm.rows.collectAsStateWithLifecycle()
    val ach by vm.achievements.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf<Mastery?>(null) }
    var continent by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<CountryRow?>(null) }
    val shown = rows.filter { (filter == null || it.mastery == filter) && (continent == null || it.country.continent == continent) }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
            Text("📊 تقدمك", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ach) { a ->
                Surface(Modifier.alpha(if (a.unlocked) 1f else 0.3f), shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                    Column(Modifier.padding(10.dp).width(92.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(a.def.emoji, fontSize = 24.sp); Text(a.def.title, fontSize = 11.sp, maxLines = 2)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { FilterChip(filter == null, { filter = null }, { Text("الكل") }) }
            items(Mastery.values().toList()) { m -> FilterChip(filter == m, { filter = if (filter == m) null else m }, { Text("${m.emoji} ${m.label}") }) }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { FilterChip(continent == null, { continent = null }, { Text("كل القارات") }) }
            items(CONTINENTS) { c -> FilterChip(continent == c, { continent = if (continent == c) null else c }, { Text(c) }) }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(shown, key = { it.country.code }) { r ->
                Surface(Modifier.fillMaxWidth().clickable { selected = r }, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(flagEmoji(r.country.code), fontSize = 26.sp); Spacer(Modifier.width(10.dp))
                        Text(r.country.name, Modifier.weight(1f), fontSize = 16.sp)
                        Text("${r.mastery.emoji} ${r.mastery.label}", color = r.mastery.color(), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    selected?.let { r ->
        val attempts by produceState<List<AttemptEntity>>(emptyList(), r.country.code) { value = vm.attempts(r.country.code) }
        val p = r.progress
        AlertDialog(onDismissRequest = { selected = null }, confirmButton = { TextButton(onClick = { selected = null }) { Text("إغلاق") } },
            title = { Text("${flagEmoji(r.country.code)} ${r.country.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("🏛️ ${r.country.capital}", fontWeight = FontWeight.Bold)
                    Text("الإتقان: ${r.mastery.emoji} ${r.mastery.label}")
                    Text("المحاولات: ${p.correct + p.wrong}  (✅ ${p.correct} · ❌ ${p.wrong} · 💡 ${p.hinted})")
                    Text("مرحلة الرحلة: ${p.stage}/5 · مراجعات: ${p.reviews}")
                    Text("آخر مراجعة: ${agoText(p.lastSeen)}")
                    Text("المراجعة القادمة: ${whenText(p.nextReview)}")
                    if (attempts.isNotEmpty()) {
                        Text("آخر الإجابات:", Modifier.padding(top = 6.dp), fontWeight = FontWeight.Bold)
                        attempts.forEach { Text("${if (it.correct) "✅" else "❌"} ${it.given}", fontSize = 13.sp) }
                    }
                }
            })
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = viewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
            Text("⚙️ الإعدادات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("فتح كل القارات و WORLD CHALLENGE"); Text("للتجربة فقط", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Switch(s["unlockAll"] == "1", { vm.put("unlockAll", if (it) "1" else "0") })
        }
        Text("عدد الدول في جلسة REVIEW")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("10", "20", "30").forEach { n -> FilterChip((s["reviewSize"] ?: "20") == n, { vm.put("reviewSize", n) }, { Text(n) }) }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = { confirm = true }, Modifier.fillMaxWidth()) { Text("🗑️ مسح كل التقدم", color = Bad) }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        title = { Text("مسح كل التقدم؟") }, text = { Text("سيتم حذف مستويات الإتقان والمراجعات وXP والإنجازات نهائيًا.") },
        confirmButton = { TextButton(onClick = { vm.reset(); confirm = false }) { Text("امسح", color = Bad) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } })
}
