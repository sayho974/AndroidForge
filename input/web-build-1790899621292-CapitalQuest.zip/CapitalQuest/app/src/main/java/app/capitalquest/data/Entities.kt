package app.capitalquest.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Static reference data (seeded from assets/countries.csv, replaceable by future updates). */
@Entity(tableName = "countries")
data class CountryEntity(
    @PrimaryKey val code: String,
    val name: String,
    val nameAlts: String,      // ';' separated
    val capital: String,
    val capitalAlts: String,   // ';' separated
    val continent: String,
    val note: String,
    val sortOrder: Int,
    // Reserved for future geographic questions (not used yet):
    val latitude: Double? = null,
    val longitude: Double? = null,
    val population: Long? = null,
) {
    val acceptedCapitals: List<String> get() = listOf(capital) + capitalAlts.split(";").filter { it.isNotBlank() }
    val acceptedNames: List<String> get() = listOf(name) + nameAlts.split(";").filter { it.isNotBlank() }
}

/** The user's memory state for ONE country. Row exists for every country; updated after every answer. */
@Entity(tableName = "progress")
data class ProgressEntity(
    @PrimaryKey val code: String,
    val stage: Int = 0,                 // journey ladder 0..5 (5 = ladder complete)
    val correct: Int = 0,
    val wrong: Int = 0,
    val hinted: Int = 0,                // answers that needed hints
    val streak: Int = 0,                // consecutive clean correct answers
    val reviews: Int = 0,               // number of SRS reviews
    val spacedSuccesses: Int = 0,       // successful reviews separated by >= 18h
    val lapses: Int = 0,
    val ease: Double = 2.3,
    val intervalDays: Double = 0.0,
    val lastSeen: Long = 0,             // epoch ms, 0 = never
    val nextReview: Long = 0,           // epoch ms, 0 = not scheduled
    val lastWasWrong: Boolean = false,
    val avgTimeMs: Long = 0,
    val mastery: Int = 0,               // Mastery.ordinal, recomputed on every write
)

@Entity(tableName = "attempts", indices = [Index("code")])
data class AttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val type: String,
    val given: String,
    val correct: Boolean,
    val hints: Int,
    val timeMs: Long,
    val ts: Long,
    val session: String,
)

@Entity(tableName = "stats")
data class StatsEntity(
    @PrimaryKey val id: Int = 1,
    val xp: Int = 0,
    val streakDays: Int = 0,
    val bestStreak: Int = 0,
    val lastActiveDay: Long = -1,
    val worldChallengesDone: Int = 0,
)

@Entity(tableName = "achievements")
data class AchievementEntity(@PrimaryKey val id: String, val unlockedAt: Long)

@Entity(tableName = "settings")
data class SettingEntity(@PrimaryKey val name: String, val value: String)
