package app.capitalquest.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CountryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(list: List<CountryEntity>)
    @Query("SELECT * FROM countries ORDER BY sortOrder") suspend fun all(): List<CountryEntity>
    @Query("SELECT * FROM countries ORDER BY sortOrder") fun observeAll(): Flow<List<CountryEntity>>
    @Query("SELECT COUNT(*) FROM countries") suspend fun count(): Int
}

@Dao
interface ProgressDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIgnore(list: List<ProgressEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(p: ProgressEntity)
    @Query("SELECT * FROM progress WHERE code = :code") suspend fun get(code: String): ProgressEntity?
    @Query("SELECT * FROM progress") suspend fun all(): List<ProgressEntity>
    @Query("SELECT * FROM progress") fun observeAll(): Flow<List<ProgressEntity>>
    @Query("DELETE FROM progress") suspend fun clear()
}

@Dao
interface AttemptDao {
    @Insert suspend fun insert(a: AttemptEntity)
    @Query("SELECT * FROM attempts WHERE code = :code ORDER BY ts DESC LIMIT :limit")
    suspend fun recent(code: String, limit: Int): List<AttemptEntity>
    @Query("SELECT given FROM attempts WHERE code = :code AND correct = 0 ORDER BY ts DESC LIMIT 20")
    suspend fun wrongGivens(code: String): List<String>
    @Query("SELECT COUNT(*) FROM attempts") suspend fun count(): Int
    @Query("DELETE FROM attempts") suspend fun clear()
}

@Dao
interface StatsDao {
    @Query("SELECT * FROM stats WHERE id = 1") suspend fun get(): StatsEntity?
    @Query("SELECT * FROM stats WHERE id = 1") fun observe(): Flow<StatsEntity?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(s: StatsEntity)
    @Query("DELETE FROM stats") suspend fun clear()
}

@Dao
interface AchievementDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(a: AchievementEntity): Long
    @Query("SELECT * FROM achievements") suspend fun all(): List<AchievementEntity>
    @Query("SELECT * FROM achievements") fun observeAll(): Flow<List<AchievementEntity>>
    @Query("DELETE FROM achievements") suspend fun clear()
}

@Dao
interface SettingDao {
    @Query("SELECT value FROM settings WHERE name = :name") suspend fun get(name: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(s: SettingEntity)
    @Query("SELECT * FROM settings") fun observeAll(): Flow<List<SettingEntity>>
}
