package app.capitalquest.data

/** Parses assets/countries.csv. Bump SEED_VERSION whenever the file changes; progress is preserved. */
object CountryCsv {
    const val SEED_VERSION = 1

    fun parse(text: String): List<CountryEntity> =
        text.lineSequence().map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .mapIndexed { i, line ->
                val f = line.split("|")
                require(f.size >= 6) { "Bad country line: $line" }
                CountryEntity(
                    code = f[0], name = f[1], nameAlts = f[2], capital = f[3], capitalAlts = f[4],
                    continent = f[5], note = f.getOrElse(6) { "" }, sortOrder = i,
                )
            }.toList()
}
