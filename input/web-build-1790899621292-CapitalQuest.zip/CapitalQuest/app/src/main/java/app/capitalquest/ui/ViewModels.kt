package app.capitalquest.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.capitalquest.CapitalQuestApp
import app.capitalquest.data.AttemptEntity
import app.capitalquest.data.CountryEntity
import app.capitalquest.data.HomeData
import app.capitalquest.data.ProgressEntity
import app.capitalquest.domain.AchievementDef
import app.capitalquest.domain.Achievements
import app.capitalquest.domain.Mastery
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

abstract class BaseVm(app: Application) : AndroidViewModel(app) {
    protected val repo = (app as CapitalQuestApp).repo
}

class HomeViewModel(app: Application) : BaseVm(app) {
    val home: StateFlow<HomeData> =
        repo.homeFlow().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeData())
    init { viewModelScope.launch { repo.ensureSeeded() } }
}

data class CountryRow(val country: CountryEntity, val progress: ProgressEntity, val mastery: Mastery)
data class AchievementRow(val def: AchievementDef, val unlocked: Boolean)

class ProgressViewModel(app: Application) : BaseVm(app) {
    init { viewModelScope.launch { repo.ensureSeeded() } }
    val rows: StateFlow<List<CountryRow>> =
        combine(repo.observeCountries(), repo.observeProgress()) { cs, ps ->
            val by = ps.associateBy { it.code }
            cs.mapNotNull { c -> by[c.code]?.let { CountryRow(c, it, Mastery.of(it)) } }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val achievements: StateFlow<List<AchievementRow>> =
        repo.observeAchievements().map { got ->
            val ids = got.map { it.id }.toSet()
            Achievements.all.map { AchievementRow(it, it.id in ids) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    suspend fun attempts(code: String): List<AttemptEntity> = repo.recentAttempts(code, 6)
}

class SettingsViewModel(app: Application) : BaseVm(app) {
    val settings: StateFlow<Map<String, String>> =
        repo.observeSettings().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())
    fun put(name: String, value: String) { viewModelScope.launch { repo.putSetting(name, value) } }
    fun reset() { viewModelScope.launch { repo.resetAll() } }
}
