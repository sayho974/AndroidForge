package app.capitalquest.domain

import app.capitalquest.data.CountryEntity
import app.capitalquest.data.ProgressEntity
import app.capitalquest.data.StatsEntity

data class AchievementDef(val id: String, val emoji: String, val title: String, val desc: String)

object Achievements {
    private fun key(c: String) = c.uppercase().replace(" ", "_")

    val all: List<AchievementDef> = buildList {
        add(AchievementDef("FIRST_CORRECT", "✨", "البداية", "أول إجابة صحيحة"))
        add(AchievementDef("LEARNED_1", "🧭", "أول محطة", "أكملت رحلة أول دولة"))
        add(AchievementDef("LEARNED_10", "🗺️", "مسافر", "أكملت 10 دول"))
        add(AchievementDef("LEARNED_50", "✈️", "رحّالة", "أكملت 50 دولة"))
        add(AchievementDef("LEARNED_100", "🌐", "جوّاب آفاق", "أكملت 100 دولة"))
        add(AchievementDef("MASTERED_1", "🏅", "أول إتقان", "أتقنت أول دولة"))
        add(AchievementDef("MASTERED_10", "🥇", "متقن", "أتقنت 10 دول"))
        add(AchievementDef("MASTERED_50", "🏆", "خبير", "أتقنت 50 دولة"))
        CONTINENTS.forEach {
            add(AchievementDef("CONT_COMPLETE_${key(it)}", continentEmoji(it), "رحلة $it", "أكملت كل دول $it"))
            add(AchievementDef("CONT_MASTER_${key(it)}", "👑", "إتقان $it", "أتقنت 90% من دول $it"))
        }
        add(AchievementDef("STREAK_3", "🔥", "3 أيام", "3 أيام متتالية"))
        add(AchievementDef("STREAK_7", "🔥", "أسبوع", "7 أيام متتالية"))
        add(AchievementDef("STREAK_30", "🔥", "شهر", "30 يومًا متتاليًا"))
        add(AchievementDef("XP_500", "⭐", "500 XP", "جمعت 500 نقطة"))
        add(AchievementDef("XP_2000", "🌟", "2000 XP", "جمعت 2000 نقطة"))
        add(AchievementDef("PERFECT_REVIEW", "🎯", "مراجعة مثالية", "جلسة مراجعة (10+ أسئلة) بدون أي خطأ"))
        add(AchievementDef("WORLD_CHALLENGE", "🌎", "WORLD CHALLENGE", "أنهيت تحدي العالم بنتيجة 80%+"))
    }
    val byId = all.associateBy { it.id }

    /** Everything earned according to the persisted state (session-based ones are added by the repository). */
    fun evaluate(countries: List<CountryEntity>, progress: List<ProgressEntity>, stats: StatsEntity): Set<String> {
        val out = HashSet<String>()
        val learned = progress.count { it.stage >= LADDER_DONE }
        val mastered = progress.count { Mastery.of(it) == Mastery.MASTERED }
        if (progress.sumOf { it.correct } > 0) out += "FIRST_CORRECT"
        listOf(1, 10, 50, 100).forEach { if (learned >= it) out += "LEARNED_$it" }
        listOf(1, 10, 50).forEach { if (mastered >= it) out += "MASTERED_$it" }
        val byCode = progress.associateBy { it.code }
        CONTINENTS.forEach { c ->
            val list = countries.filter { it.continent == c }
            if (list.isEmpty()) return@forEach
            if (list.all { (byCode[it.code]?.stage ?: 0) >= LADDER_DONE }) out += "CONT_COMPLETE_${key(c)}"
            val m = list.count { byCode[it.code]?.let { p -> Mastery.of(p) == Mastery.MASTERED } == true }
            if (m >= Math.ceil(list.size * 0.9).toInt()) out += "CONT_MASTER_${key(c)}"
        }
        listOf(3, 7, 30).forEach { if (stats.streakDays >= it) out += "STREAK_$it" }
        listOf(500, 2000).forEach { if (stats.xp >= it) out += "XP_$it" }
        return out
    }
}
