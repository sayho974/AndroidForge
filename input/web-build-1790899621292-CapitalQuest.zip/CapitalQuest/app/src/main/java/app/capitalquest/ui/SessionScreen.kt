package app.capitalquest.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.capitalquest.domain.QType
import app.capitalquest.domain.flagEmoji
import kotlin.math.roundToInt

@Composable
fun SessionScreen(onExit: () -> Unit, vm: SessionViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text("✕", fontSize = 20.sp) }
            val p by animateFloatAsState(ui.progressFraction, label = "p")
            LinearProgressIndicator(progress = { p }, Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)))
            Spacer(Modifier.width(10.dp))
            Text("⭐ ${ui.sessionXp}", fontWeight = FontWeight.Bold)
        }
        when {
            ui.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            ui.phase == Phase.EMPTY -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Text(ui.message, fontSize = 20.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp)); BigButton("رجوع", onExit)
            }
            ui.phase == Phase.SUMMARY -> SummaryView(ui.summary!!, onExit, vm::continueJourney)
            else -> QuestionContent(ui, vm)
        }
    }
}

@Composable
private fun ColumnScope.QuestionContent(ui: SessionUi, vm: SessionViewModel) {
    val q = ui.question ?: return
    val c = q.country
    val shake = remember { Animatable(0f) }
    LaunchedEffect(ui.wrongTick) {
        if (ui.wrongTick > 0) { repeat(3) { shake.animateTo(14f, tween(45)); shake.animateTo(-14f, tween(45)) }; shake.animateTo(0f, tween(45)) }
    }
    val revealed = ui.phase == Phase.REVEALED
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(8.dp))
        Surface(Modifier.fillMaxWidth().offset { IntOffset(shake.value.roundToInt(), 0) },
            shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                when (q.type) {
                    QType.LEARN -> {
                        Text("محطة جديدة 🧭", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                        Text(flagEmoji(c.code), fontSize = 72.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(c.name, fontSize = 28.sp, fontWeight = FontWeight.Bold); SpeakButton(c.name) }
                        Text("العاصمة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("🏛️ ${c.capital}", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary); SpeakButton(c.capital) }
                        if (c.note.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(c.note, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    QType.CAPITAL_TO_COUNTRY -> {
                        Text("🏛️", fontSize = 60.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(c.capital, fontSize = 32.sp, fontWeight = FontWeight.Bold); SpeakButton(c.capital) }
                        Text("Which country is this the capital of?", fontSize = 16.sp)
                    }
                    else -> {
                        Text(flagEmoji(c.code), fontSize = 72.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(c.name, fontSize = 30.sp, fontWeight = FontWeight.Bold); SpeakButton(c.name) }
                        Text(if (q.type == QType.FULL_RECALL) "Capital:" else "What is the capital?", fontSize = 16.sp)
                        if (q.cue.isNotEmpty() && !revealed) Text(q.cue, fontSize = 22.sp, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))

        if (q.type == QType.LEARN) {
            BigButton("فهمت ✓ — يلا نختبر", vm::ackLearn)
        } else if (!revealed) {
            if (q.type == QType.MCQ) {
                q.choices.forEachIndexed { i, choice ->
                    val wrong = choice in ui.wrongChoices
                    OutlinedButton(onClick = { vm.submit(choice) }, enabled = !wrong, modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp).padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp)) { Text("${'A' + i}) $choice", fontSize = 18.sp) }
                }
            } else {
                var text by remember(ui.qid, ui.wrongTick) { mutableStateOf("") }
                val focus = remember { FocusRequester() }
                LaunchedEffect(ui.qid, ui.wrongTick) { runCatching { focus.requestFocus() } }
                OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().focusRequester(focus), singleLine = true,
                    placeholder = { Text(if (q.type == QType.CAPITAL_TO_COUNTRY) "Country…" else "Capital…") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done, capitalization = KeyboardCapitalization.Words),
                    keyboardActions = KeyboardActions(onDone = { vm.submit(text) }), shape = RoundedCornerShape(16.dp))
                Spacer(Modifier.height(8.dp))
                BigButton("Check ✓", { vm.submit(text) }, enabled = text.isNotBlank())
            }
            if (ui.hintText.isNotEmpty() || ui.phase == Phase.HINTING) {
                Spacer(Modifier.height(8.dp))
                Surface(shape = RoundedCornerShape(16.dp), color = if (ui.phase == Phase.HINTING) Bad.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        if (ui.phase == Phase.HINTING) Text("مش بالظبط — جرّب تاني 🤔", fontWeight = FontWeight.Bold)
                        Text("💡 ${ui.hintText}", fontSize = 18.sp)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = vm::requestHint, enabled = ui.hintLevel < 3) { Text("💡 تلميح (${ui.hintLevel}/3)") }
                TextButton(onClick = vm::showAnswer) { Text("إظهار الإجابة") }
            }
        } else {
            val ok = ui.firstTryCorrect == true
            Surface(shape = RoundedCornerShape(20.dp), color = (if (ok) Good else Bad).copy(alpha = 0.18f)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ui.message, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(q.answerDisplay, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        SpeakButton(q.answerDisplay)
                    }
                    if (c.note.isNotBlank()) Text(c.note, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (ui.xpGained > 0) Text("⭐ +${ui.xpGained} XP", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    ui.masteryChange?.let { Text(it) }
                    ui.newAchievements.forEach { Text("🏆 ${it.emoji} ${it.title}", fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(12.dp))
            BigButton("التالي ›", vm::next)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SummaryView(s: Summary, onExit: () -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("🎉 خلصت الجلسة!", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatChip("🌍", "${s.countries}", "دول", Modifier.weight(1f))
            StatChip("✅", "${s.correct}", "صح", Modifier.weight(1f))
            StatChip("❌", "${s.wrong}", "خطأ", Modifier.weight(1f))
            StatChip("⭐", "${s.xp}", "XP", Modifier.weight(1f))
        }
        if (s.improved.isNotEmpty()) Text("📈 تحسّنت: ${s.improved.joinToString("، ")}", textAlign = TextAlign.Center)
        if (s.needMore.isNotEmpty()) Text("🔁 تحتاج مراجعة إضافية: ${s.needMore.joinToString("، ")}", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary)
        s.achievements.forEach { Text("🏆 ${it.emoji} ${it.title} — ${it.desc}", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
        Spacer(Modifier.height(8.dp))
        if (s.canContinue) BigButton("كمّل الرحلة ›", onContinue)
        BigButton("رجوع للرئيسية", onExit, container = MaterialTheme.colorScheme.surfaceVariant, content = MaterialTheme.colorScheme.onSurface)
    }
}
