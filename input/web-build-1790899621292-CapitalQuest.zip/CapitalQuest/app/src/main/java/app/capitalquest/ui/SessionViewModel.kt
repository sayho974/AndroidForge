package app.capitalquest.ui

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import app.capitalquest.data.AnswerInput
import app.capitalquest.data.ProgressEntity
import app.capitalquest.domain.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

enum class Phase { LEARN, ANSWERING, HINTING, REVEALED, SUMMARY, EMPTY }

data class Summary(
    val countries: Int, val correct: Int, val wrong: Int,
    val improved: List<String>, val needMore: List<String>, val xp: Int,
    val achievements: List<AchievementDef>, val canContinue: Boolean,
)

data class SessionUi(
    val loading: Boolean = true,
    val phase: Phase = Phase.ANSWERING,
    val qid: Int = 0,
    val question: Question? = null,
    val progressFraction: Float = 0f,
    val hintLevel: Int = 0,
    val hintText: String = "",
    val wrongChoices: Set<String> = emptySet(),
    val wrongTick: Int = 0,
    val firstTryCorrect: Boolean? = null,   // REVEALED: true = correct on first attempt
    val xpGained: Int = 0,
    val sessionXp: Int = 0,
    val message: String = "",
    val masteryChange: String? = null,
    val newAchievements: List<AchievementDef> = emptyList(),
    val summary: Summary? = null,
)

class SessionViewModel(app: Application, saved: SavedStateHandle) : BaseVm(app) {
    private val mode = SessionMode.valueOf(saved.get<String>("mode") ?: "REVIEW")
    private val continentIdx = saved.get<String>("continent")?.toIntOrNull() ?: -1

    private val _ui = MutableStateFlow(SessionUi())
    val ui: StateFlow<SessionUi> = _ui.asStateFlow()

    private data class Item(val code: String, val type: QType, val affectsSrs: Boolean, val requeues: Int = 0)

    private val sessionId = UUID.randomUUID().toString()
    private val queue = ArrayDeque<Item>()
    private val active = ArrayList<String>()           // journey: countries currently being learned
    private var rr = 0
    private var current: Item? = null
    private var progressCache = HashMap<String, ProgressEntity>()
    private var known: Set<String> = emptySet()

    private var shownAt = 0L
    private var hintsUsed = 0
    private var firstAttemptDone = false
    private var busy = false

    private val touched = LinkedHashMap<String, Mastery>()
    private val needMore = LinkedHashSet<String>()
    private val sessionAch = ArrayList<AchievementDef>()
    private var correctCount = 0; private var wrongCount = 0
    private var firstTryClean = 0; private var asked = 0
    private var sessionXp = 0
    private var totalSteps = 1; private var doneSteps = 0
    private var qid = 0

    init { start() }

    private fun byCode(code: String) = repo.countries.first { it.code == code }

    private fun reviewType(p: ProgressEntity): QType = when (Mastery.of(p)) {
        Mastery.NEW, Mastery.WEAK -> QType.MCQ
        Mastery.LEARNING -> QType.COUNTRY_TO_CAPITAL
        Mastery.GOOD -> if (Random.nextBoolean()) QType.CAPITAL_TO_COUNTRY else QType.FULL_RECALL
        Mastery.MASTERED -> QType.FULL_RECALL
    }

    private fun start() = viewModelScope.launch {
        repo.ensureSeeded()
        known = QuestionGenerator.known(repo.countries)
        progressCache = HashMap(repo.allProgress().associateBy { it.code })
        queue.clear(); active.clear(); rr = 0
        touched.clear(); needMore.clear(); sessionAch.clear()
        correctCount = 0; wrongCount = 0; firstTryClean = 0; asked = 0; sessionXp = 0; doneSteps = 0
        when (mode) {
            SessionMode.JOURNEY -> {
                val name = CONTINENTS.getOrNull(continentIdx)
                if (name == null) return@launch empty("اختر قارة أولًا")
                repo.putSetting("lastContinent", continentIdx.toString())
                val pool = repo.journeyPool(name).take(BATCH)
                if (pool.isEmpty()) return@launch empty("🎉 أنهيت رحلة $name بالكامل! جرّب REVIEW لتثبيت المعلومات.")
                active += pool.map { it.code }
                totalSteps = pool.size * LADDER_DONE
                doneSteps = pool.sumOf { progressCache[it.code]?.stage ?: 0 }
            }
            SessionMode.REVIEW -> {
                val size = repo.setting("reviewSize", "20").toInt()
                repo.reviewQueue(size).forEach { queue += Item(it.code, reviewType(it), true) }
                if (queue.isEmpty()) return@launch empty("✅ مفيش دول محتاجة مراجعة دلوقتي. ارجع بعدين!")
                totalSteps = queue.size
            }
            SessionMode.WORLD -> {
                repo.worldQueue(25).forEach { queue += Item(it.code, reviewType(it), true) }
                if (queue.isEmpty()) return@launch empty("كمّل الرحلة الأول وبعدين ارجع للتحدي 🌎")
                totalSteps = queue.size
            }
        }
        showNext()
    }

    private fun empty(msg: String) = _ui.update { it.copy(loading = false, phase = Phase.EMPTY, message = msg) }

    private fun fraction(): Float = (doneSteps.toFloat() / totalSteps.coerceAtLeast(1)).coerceIn(0f, 1f)

    private fun nextItem(): Item? {
        if (mode != SessionMode.JOURNEY) return queue.removeFirstOrNull()
        if (active.isEmpty()) return null
        rr %= active.size
        val code = active[rr]; rr++
        val stage = progressCache[code]?.stage ?: 0
        return Item(code, typeForStage(stage), affectsSrs = false)
    }

    private fun showNext() {
        viewModelScope.launch {
            val item = nextItem() ?: return@launch finish()
            current = item
            hintsUsed = 0; firstAttemptDone = false; busy = false
            val c = byCode(item.code)
            val q = QuestionGenerator.build(c, item.type, repo.countries, repo.confusions(item.code))
            shownAt = SystemClock.elapsedRealtime()
            qid++
            _ui.update {
                it.copy(
                    loading = false, phase = if (q.type == QType.LEARN) Phase.LEARN else Phase.ANSWERING,
                    qid = qid, question = q, hintLevel = 0, hintText = "", wrongChoices = emptySet(),
                    firstTryCorrect = null, xpGained = 0, message = "", masteryChange = null,
                    newAchievements = emptyList(), progressFraction = fraction(), sessionXp = sessionXp,
                )
            }
        }
    }

    // ---- user actions ----

    fun ackLearn() {
        val item = current ?: return
        if (busy) return
        busy = true
        viewModelScope.launch {
            repo.markIntroduced(item.code)
            progressCache[item.code] = repo.progressOf(item.code)
            touched.putIfAbsent(item.code, Mastery.NEW)
            doneSteps = active.sumOf { progressCache[it]?.stage ?: 0 }
            showNext()
        }
    }

    fun requestHint() {
        val q = _ui.value.question ?: return
        val phase = _ui.value.phase
        if (phase != Phase.ANSWERING && phase != Phase.HINTING) return
        val level = (_ui.value.hintLevel + 1).coerceAtMost(3)
        if (phase == Phase.ANSWERING && !firstAttemptDone) hintsUsed = level   // asking for help is recorded
        _ui.update { it.copy(hintLevel = level, hintText = Hints.build(q.answerDisplay, level)) }
    }

    fun submit(given: String) {
        val q = _ui.value.question ?: return
        val phase = _ui.value.phase
        if ((phase != Phase.ANSWERING && phase != Phase.HINTING) || busy || given.isBlank()) return
        val ok = if (q.type == QType.MCQ)
            AnswerMatcher.normalize(given) in q.accepted.map { AnswerMatcher.normalize(it) }
        else AnswerMatcher.check(given, q.accepted, known) != Match.WRONG
        busy = true
        viewModelScope.launch {
            if (ok) {
                if (!firstAttemptDone) record(given, true)
                reveal(firstTry = !wasWrong(), retry = wasWrong())
            } else {
                if (!firstAttemptDone) record(given, false)
                val level = (_ui.value.hintLevel + 1).coerceAtMost(3)
                _ui.update {
                    it.copy(phase = Phase.HINTING, hintLevel = level, hintText = Hints.build(q.answerDisplay, level),
                        wrongTick = it.wrongTick + 1, wrongChoices = it.wrongChoices + given)
                }
                busy = false
            }
        }
    }

    fun showAnswer() {
        val phase = _ui.value.phase
        if ((phase != Phase.ANSWERING && phase != Phase.HINTING) || busy) return
        busy = true
        viewModelScope.launch {
            if (!firstAttemptDone) record("(skipped)", false)
            reveal(firstTry = false, retry = false)
        }
    }

    fun next() { if (_ui.value.phase == Phase.REVEALED) showNext() }
    fun continueJourney() { _ui.update { SessionUi() }; start() }

    // ---- internals ----

    private var lastWrong = false
    private fun wasWrong() = lastWrong

    private suspend fun record(given: String, correct: Boolean) {
        val item = current ?: return
        val q = _ui.value.question ?: return
        firstAttemptDone = true
        lastWrong = !correct
        val timeMs = SystemClock.elapsedRealtime() - shownAt
        val out = repo.submitAnswer(
            AnswerInput(item.code, q.type, given, correct, hintsUsed, timeMs,
                fromJourney = mode == SessionMode.JOURNEY,
                affectsSrs = mode != SessionMode.JOURNEY && item.affectsSrs, sessionId = sessionId)
        )
        progressCache[item.code] = out.progress
        touched.putIfAbsent(item.code, out.before)
        asked++
        if (correct) { correctCount++; if (hintsUsed == 0) firstTryClean++ } else { wrongCount++; needMore += item.code }
        sessionXp += out.xp
        sessionAch += out.newAchievements

        if (mode == SessionMode.JOURNEY) {
            doneSteps = active.sumOf { progressCache[it]?.stage ?: 0 }
            if (out.ladderCompleted) {
                val idx = active.indexOf(item.code)
                if (idx >= 0) { active.removeAt(idx); if (idx < rr) rr-- }
            }
        } else {
            doneSteps++
            if (!correct && item.requeues < 2) {              // wrong -> comes back later in this session, easier
                queue.add(minOf(3, queue.size), Item(item.code, QType.MCQ, affectsSrs = false, requeues = item.requeues + 1))
                totalSteps++
            }
        }
        val change = if (out.after != out.before) "${out.before.emoji} → ${out.after.emoji} ${out.after.label}" else null
        _ui.update { it.copy(xpGained = out.xp, sessionXp = sessionXp, newAchievements = out.newAchievements, masteryChange = change,
            progressFraction = fraction()) }
    }

    private fun reveal(firstTry: Boolean, retry: Boolean) {
        val msg = when {
            firstTry -> if (hintsUsed > 0) "صح بمساعدة التلميح 👍" else "صح! 🎉"
            retry -> "تمام، دي الإجابة الصحيحة. هنرجّعها لك تاني قريب."
            else -> "الإجابة الصحيحة:"
        }
        _ui.update { it.copy(phase = Phase.REVEALED, firstTryCorrect = firstTry, message = msg, hintText = "") }
        busy = false
    }

    private fun finish() {
        viewModelScope.launch {
            val ach = repo.finishSession(mode, asked, firstTryClean)
            sessionAch += ach
            val improved = touched.filter { (code, m0) ->
                Mastery.of(progressCache[code] ?: ProgressEntity(code)).ordinal > m0.ordinal
            }.keys.map { byCode(it).name }
            val weak = touched.keys.filter { Mastery.of(progressCache[it] ?: ProgressEntity(it)) == Mastery.WEAK } .map { byCode(it).name }
            val canContinue = mode == SessionMode.JOURNEY && continentIdx >= 0 &&
                repo.journeyPool(CONTINENTS[continentIdx]).isNotEmpty()
            _ui.update {
                it.copy(loading = false, phase = Phase.SUMMARY, progressFraction = 1f, sessionXp = sessionXp,
                    summary = Summary(touched.size, correctCount, wrongCount, improved, weak, sessionXp,
                        sessionAch.distinctBy { a -> a.id }, canContinue))
            }
        }
    }

    companion object { const val BATCH = 5 }
}
