package app.capitalquest

import android.app.Application
import app.capitalquest.data.AppDatabase
import app.capitalquest.data.Repository

class CapitalQuestApp : Application() {
    val db by lazy { AppDatabase.build(this) }
    val repo by lazy { Repository(db, this) }
}
