package app.capitalquest.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.capitalquest.domain.Mastery
import app.capitalquest.tts.LocalSpeaker

private val Scheme = darkColorScheme(
    primary = Color(0xFF4FD1C5), onPrimary = Color(0xFF00201D),
    secondary = Color(0xFFFFB84D), onSecondary = Color(0xFF2A1A00),
    background = Color(0xFF0E1726), onBackground = Color(0xFFEAF1FF),
    surface = Color(0xFF16233A), onSurface = Color(0xFFEAF1FF),
    surfaceVariant = Color(0xFF1F2F4D), onSurfaceVariant = Color(0xFFB7C6E6),
    error = Color(0xFFFF6B6B),
)

@Composable fun CapitalQuestTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Scheme, content = content)

val Good = Color(0xFF3DDC84)
val Bad = Color(0xFFFF6B6B)

fun Mastery.color(): Color = when (this) {
    Mastery.NEW -> Color(0xFFFF5D5D); Mastery.WEAK -> Color(0xFFFF9F43); Mastery.LEARNING -> Color(0xFFFFD84D)
    Mastery.GOOD -> Color(0xFF3DDC84); Mastery.MASTERED -> Color(0xFF4DA3FF)
}

@Composable
fun StatChip(emoji: String, value: String, label: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 22.sp)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun BigButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
              container: Color = MaterialTheme.colorScheme.primary, content: Color = MaterialTheme.colorScheme.onPrimary) {
    Button(onClick, modifier.fillMaxWidth().heightIn(min = 56.dp), enabled = enabled, shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)) {
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SpeakButton(text: String) {
    val sp = LocalSpeaker.current ?: return
    if (!sp.available) return
    TextButton(onClick = { sp.speak(text) }) { Text("🔊", fontSize = 22.sp) }
}

fun whenText(ts: Long, now: Long = System.currentTimeMillis()): String {
    if (ts <= 0) return "—"
    val d = ts - now
    if (d <= 0) return "الآن"
    val min = d / 60_000
    return when {
        min < 60 -> "بعد $min دقيقة"
        min < 48 * 60 -> "بعد ${min / 60} ساعة"
        else -> "بعد ${min / 1440} يوم"
    }
}

fun agoText(ts: Long, now: Long = System.currentTimeMillis()): String {
    if (ts <= 0) return "لم تظهر بعد"
    val min = (now - ts) / 60_000
    return when {
        min < 1 -> "الآن"
        min < 60 -> "منذ $min دقيقة"
        min < 48 * 60 -> "منذ ${min / 60} ساعة"
        else -> "منذ ${min / 1440} يوم"
    }
}
