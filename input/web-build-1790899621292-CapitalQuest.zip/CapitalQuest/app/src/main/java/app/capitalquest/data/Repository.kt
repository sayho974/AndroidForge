package app.capitalquest.data

import android.content.Context
import androidx.room.withTransaction
import app.capitalquest.domain.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate

data class AnswerInput(
    val code: String, val type: QType, val given: String, val correct: Boolean, val hints: Int,
    val timeMs: Long, val fromJourney: Boolean, val affectsSrs: Boolean, val sessionId: String,
)

data class AnswerOutcome(
    val progress: ProgressEntity, val before: Mastery, val after: Mastery, val xp: Int,
    val newAchievements: List<AchievementDef>, val ladderCompleted: Boolean,
)

data class ProblemItem(val country: CountryEntity, val progress: ProgressEntity)
data class HomeData(
    val total: Int = 0, val learned: Int = 0, val mastered: Int = 0, val masteryPercent: Int = 0,
    val dueCount: Int = 0, val problems: List<ProblemItem> = emptyList(),
    val xp: Int = 0, val streak: Int = 0, val continents: List<ContinentState> = emptyList(),
    val worldUnlocked: Boolean = false, val lastContinent: Int = -1,
)

class Repository(private val db: AppDatabase, private val ctx: Context) {
    private val countryDao = db.countryDao()
    private val progressDao = db.progressDao()
    private val attemptDao = db.attemptDao()
    private val statsDao = db.statsDao()
    private val achDao = db.achievementDao()
    private val settingDao = db.settingDao()

    @Volatile var countries: List<CountryEntity> = emptyList(); private set
    private val seedMutex = Mutex()

    /** Idempotent: seeds countries + one blank progress row per country. Never touches existing progress. */
    suspend fun ensureSeeded() = seedMutex.withLock {
        val v = settingDao.get("seedVersion")?.toIntOrNull() ?: 0
        if (v < CountryCsv.SEED_VERSION || countryDao.count() == 0) {
            val text = ctx.assets.open("countries.csv").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val list = CountryCsv.parse(text)
            db.withTransaction {
                countryDao.upsertAll(list)
                progressDao.insertIgnore(list.map { ProgressEntity(it.code) })
                settingDao.put(SettingEntity("seedVersion", CountryCsv.SEED_VERSION.toString()))
            }
        }
        countries = countryDao.all()
    }

    // ---------- settings ----------
    suspend fun setting(name: String, def: String) = settingDao.get(name) ?: def
    suspend fun putSetting(name: String, value: String) = settingDao.put(SettingEntity(name, value))
    fun observeSettings(): Flow<Map<String, String>> =
        settingDao.observeAll().map { l -> l.associate { it.name to it.value } }

    // ---------- reads ----------
    suspend fun allProgress() = progressDao.all()
    suspend fun progressOf(code: String) = progressDao.get(code) ?: ProgressEntity(code)
    suspend fun recentAttempts(code: String, n: Int = 8) = attemptDao.recent(code, n)
    suspend fun confusions(code: String) = attemptDao.wrongGivens(code)
    suspend fun stats() = statsDao.get() ?: StatsEntity()
    fun observeProgress() = progressDao.observeAll()
    fun observeCountries() = countryDao.observeAll()
    fun observeAchievements() = achDao.observeAll()
    fun observeStats() = statsDao.observe()

    fun homeFlow(): Flow<HomeData> = combine(
        progressDao.observeAll(), statsDao.observe(), countryDao.observeAll(), observeSettings(),
    ) { prog, stats, ctry, settings ->
        val now = System.currentTimeMillis()
        val byCode = ctry.associateBy { it.code }
        val unlockAll = settings["unlockAll"] == "1"
        val states = Journey.states(ctry, prog, unlockAll)
        val cands = SrsEngine.reviewCandidates(prog, now)
        val mastery = prog.map { Mastery.of(it) }
        HomeData(
            total = ctry.size,
            learned = prog.count { it.stage >= LADDER_DONE },
            mastered = mastery.count { it == Mastery.MASTERED },
            masteryPercent = if (ctry.isEmpty()) 0 else (100 * mastery.sumOf { it.weight } / ctry.size).toInt(),
            dueCount = cands.size,
            problems = cands.filter { SrsEngine.isProblem(it) }.take(3)
                .mapNotNull { p -> byCode[p.code]?.let { ProblemItem(it, p) } },
            xp = stats?.xp ?: 0, streak = effectiveStreak(stats),
            continents = states, worldUnlocked = Journey.worldUnlocked(states, unlockAll),
            lastContinent = settings["lastContinent"]?.toIntOrNull() ?: -1,
        )
    }

    /** A streak whose last active day is older than yesterday is already broken. */
    private fun effectiveStreak(s: StatsEntity?): Int {
        if (s == null) return 0
        val today = LocalDate.now().toEpochDay()
        return if (s.lastActiveDay >= today - 1) s.streakDays else 0
    }

    // ---------- session building ----------
    suspend fun journeyPool(continent: String): List<CountryEntity> {
        val prog = progressDao.all().associateBy { it.code }
        return countries.filter { it.continent == continent && (prog[it.code]?.stage ?: 0) < LADDER_DONE }
            .sortedWith(compareByDescending<CountryEntity> { prog[it.code]?.stage ?: 0 }.thenBy { it.sortOrder })
    }

    suspend fun reviewQueue(limit: Int): List<ProgressEntity> =
        SrsEngine.reviewCandidates(progressDao.all(), System.currentTimeMillis()).take(limit)

    /** World challenge: weakest/due first, then fill with started countries; every continent is represented. */
    suspend fun worldQueue(size: Int): List<ProgressEntity> {
        val now = System.currentTimeMillis()
        val all = progressDao.all().filter { it.stage >= LADDER_DONE }
        val prioritized = all.sortedByDescending { SrsEngine.priority(it, now) }.take(size / 2)
        val rest = (all - prioritized.toSet()).shuffled().take(size - prioritized.size)
        return (prioritized + rest).shuffled()
    }

    // ---------- the heart: every answer is persisted immediately in ONE transaction ----------
    suspend fun markIntroduced(code: String, now: Long = System.currentTimeMillis()) {
        val p = progressDao.get(code) ?: ProgressEntity(code)
        val q = p.copy(stage = maxOf(p.stage, 1), lastSeen = now)
        progressDao.upsert(q.copy(mastery = Mastery.of(q).ordinal))
    }

    suspend fun submitAnswer(a: AnswerInput, now: Long = System.currentTimeMillis()): AnswerOutcome =
        db.withTransaction {
            val p = progressDao.get(a.code) ?: ProgressEntity(a.code)
            val before = Mastery.of(p)
            val clean = a.correct && a.hints == 0
            var q = p.copy(
                lastSeen = now,
                lastWasWrong = !a.correct,
                correct = p.correct + if (a.correct) 1 else 0,
                wrong = p.wrong + if (a.correct) 0 else 1,
                hinted = p.hinted + if (a.hints > 0) 1 else 0,
                streak = if (!a.correct) 0 else if (clean) p.streak + 1 else p.streak,
                avgTimeMs = if (!clean) p.avgTimeMs else if (p.avgTimeMs == 0L) a.timeMs else (p.avgTimeMs * 7 + a.timeMs) / 8,
            )
            var ladderCompleted = false

            if (a.fromJourney) {                                     // ladder progression
                val newStage = when {
                    clean -> minOf(LADDER_DONE, p.stage + 1)
                    a.correct -> p.stage                              // needed help: repeat this stage later
                    else -> maxOf(1, p.stage - 1)                     // wrong: step back, never punished harder
                }
                q = q.copy(stage = newStage)
                if (!a.correct) {                                    // see it again soon
                    q = q.copy(reps = 0, nextReview = if (p.nextReview == 0L || p.nextReview > now + SrsEngine.RELEARN_MS) now + SrsEngine.RELEARN_MS else p.nextReview)
                }
                if (newStage >= LADDER_DONE && p.stage < LADDER_DONE) {   // graduate into spaced repetition
                    ladderCompleted = true
                    q = q.copy(reps = maxOf(1, q.reps), intervalDays = maxOf(1.0, q.intervalDays), nextReview = now + SrsEngine.DAY_MS)
                }
            }

            if (a.affectsSrs) {                                     // review / world: full SM-2 update
                val grade = SrsEngine.gradeFor(a.correct, a.hints, a.type, a.timeMs)
                val r = SrsEngine.next(SrsState(p.ease, p.intervalDays, p.reps, p.lapses), grade, now)
                val spaced = a.correct && grade >= Grade.GOOD && p.lastSeen > 0 && now - p.lastSeen >= SrsEngine.SPACED_GAP_MS
                q = q.copy(
                    ease = r.state.ease, intervalDays = r.state.intervalDays, reps = r.state.reps,
                    lapses = r.state.lapses, nextReview = r.nextReviewAt, reviews = p.reviews + 1,
                    spacedSuccesses = when { grade == Grade.AGAIN -> p.spacedSuccesses / 2; spaced -> p.spacedSuccesses + 1; else -> p.spacedSuccesses },
                )
            }
            q = q.copy(mastery = Mastery.of(q).ordinal)
            progressDao.upsert(q)
            attemptDao.insert(AttemptEntity(code = a.code, type = a.type.name, given = a.given, correct = a.correct,
                hints = a.hints, timeMs = a.timeMs, ts = now, session = a.sessionId))

            val base = when (a.type) { QType.MCQ -> 5; QType.COUNTRY_TO_CAPITAL, QType.CAPITAL_TO_COUNTRY -> 8; QType.FULL_RECALL -> 12; QType.LEARN -> 0 }
            val xp = when {
                !a.correct -> 0
                a.hints > 0 -> maxOf(2, base * 2 / 5)
                else -> base + if (p.lastWasWrong) 5 else 0           // comeback bonus
            }
            val s = statsDao.get() ?: StatsEntity()
            val today = LocalDate.now().toEpochDay()
            val streak = when (s.lastActiveDay) { today -> s.streakDays; today - 1 -> s.streakDays + 1; else -> 1 }
            val s2 = s.copy(xp = s.xp + xp, streakDays = streak, bestStreak = maxOf(s.bestStreak, streak), lastActiveDay = today)
            statsDao.upsert(s2)

            val unlocked = unlockNew(Achievements.evaluate(countries, progressDao.all(), s2))
            AnswerOutcome(q, before, Mastery.of(q), xp, unlocked, ladderCompleted)
        }

    private suspend fun unlockNew(ids: Set<String>): List<AchievementDef> {
        val now = System.currentTimeMillis()
        return ids.mapNotNull { id -> if (achDao.insert(AchievementEntity(id, now)) != -1L) Achievements.byId[id] else null }
    }

    /** Session-level achievements (perfect review, world challenge). */
    suspend fun finishSession(mode: SessionMode, questions: Int, firstTryCorrect: Int): List<AchievementDef> = db.withTransaction {
        val ids = HashSet<String>()
        if (mode == SessionMode.REVIEW && questions >= 10 && firstTryCorrect == questions) ids += "PERFECT_REVIEW"
        if (mode == SessionMode.WORLD && questions >= 10 && firstTryCorrect * 10 >= questions * 8) {
            ids += "WORLD_CHALLENGE"
            statsDao.upsert((statsDao.get() ?: StatsEntity()).let { it.copy(worldChallengesDone = it.worldChallengesDone + 1) })
        }
        unlockNew(ids)
    }

    suspend fun resetAll() = db.withTransaction {
        progressDao.clear(); attemptDao.clear(); statsDao.clear(); achDao.clear()
        progressDao.insertIgnore(countries.map { ProgressEntity(it.code) })
    }
}
