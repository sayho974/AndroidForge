package app.capitalquest.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Real on-device SQLite (Room). NEVER use fallbackToDestructiveMigration():
 * when the schema changes, write a Migration so the user's progress survives.
 */
@Database(
    entities = [CountryEntity::class, ProgressEntity::class, AttemptEntity::class,
        StatsEntity::class, AchievementEntity::class, SettingEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun countryDao(): CountryDao
    abstract fun progressDao(): ProgressDao
    abstract fun attemptDao(): AttemptDao
    abstract fun statsDao(): StatsDao
    abstract fun achievementDao(): AchievementDao
    abstract fun settingDao(): SettingDao

    companion object {
        const val FILE = "capitalquest.db"
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, FILE).build()
    }
}
