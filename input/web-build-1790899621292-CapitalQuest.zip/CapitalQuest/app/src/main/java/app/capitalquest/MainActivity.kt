package app.capitalquest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.capitalquest.tts.LocalSpeaker
import app.capitalquest.tts.Speaker
import app.capitalquest.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CapitalQuestTheme {
                val ctx = LocalContext.current
                val speaker = remember { Speaker(ctx) }
                DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
                CompositionLocalProvider(LocalSpeaker provides speaker) {
                    Surface(Modifier.fillMaxSize(), color = androidx.compose.material3.MaterialTheme.colorScheme.background) { AppNav() }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onJourney = { nav.navigate("journey") },
                onReview = { nav.navigate("session/REVIEW") },
                onWorld = { nav.navigate("session/WORLD") },
                onProgress = { nav.navigate("progress") },
                onSettings = { nav.navigate("settings") },
            )
        }
        composable("journey") { JourneyScreen(onBack = { nav.popBackStack() }, onStart = { i -> nav.navigate("session/JOURNEY?continent=$i") }) }
        composable(
            "session/{mode}?continent={continent}",
            arguments = listOf(
                navArgument("mode") { type = NavType.StringType },
                navArgument("continent") { type = NavType.StringType; defaultValue = "-1" },
            ),
        ) { SessionScreen(onExit = { nav.popBackStack() }) }
        composable("progress") { ProgressScreen(onBack = { nav.popBackStack() }) }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
    }
}
