package app.capitalquest

import app.capitalquest.data.CountryCsv
import app.capitalquest.data.ProgressEntity
import app.capitalquest.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import kotlin.random.Random

class CoreLogicTest {
    private val now = 1_700_000_000_000L
    private val DAY = SrsEngine.DAY_MS

    private fun countries() = CountryCsv.parse(File("src/main/assets/countries.csv").readText())

    // ---------- dataset ----------
    @Test fun dataset_is_complete_and_consistent() {
        val c = countries()
        assertEquals(197, c.size)
        assertEquals(c.size, c.map { it.code }.toSet().size)
        assertTrue(c.all { it.capital.isNotBlank() && it.name.isNotBlank() && it.continent in CONTINENTS })
        assertEquals(54, c.count { it.continent == "Africa" })
        val za = c.first { it.code == "ZA" }
        assertTrue(za.acceptedCapitals.containsAll(listOf("Pretoria", "Cape Town", "Bloemfontein")))
        assertTrue(c.first { it.code == "BO" }.acceptedCapitals.contains("La Paz"))
    }

    // ---------- SRS: wrong answers come back soon, right answers go far ----------
    @Test fun wrong_answer_returns_in_ten_minutes() {
        val r = SrsEngine.next(SrsState(2.3, 10.0, 4, 0), Grade.AGAIN, now)
        assertEquals(now + SrsEngine.RELEARN_MS, r.nextReviewAt)
        assertEquals(1, r.state.lapses); assertEquals(0, r.state.reps)
    }

    @Test fun repeated_success_spreads_reviews_out() {
        var s = SrsState(); var t = now; val gaps = ArrayList<Double>()
        repeat(6) { val r = SrsEngine.next(s, Grade.GOOD, t); gaps += r.state.intervalDays; s = r.state; t = r.nextReviewAt }
        assertEquals(1.0, gaps[0], 0.001); assertEquals(3.0, gaps[1], 0.001)
        for (i in 1 until gaps.size) assertTrue("interval must grow", gaps[i] > gaps[i - 1])
        assertTrue(gaps.last() > 30)
    }

    @Test fun country_with_many_lapses_grows_slower_than_clean_one() {
        val clean = SrsEngine.next(SrsState(2.3, 6.0, 3, 0), Grade.GOOD, now).state.intervalDays
        val shaky = SrsEngine.next(SrsState(2.3, 6.0, 3, 4), Grade.GOOD, now).state.intervalDays
        assertTrue(shaky < clean)
    }

    @Test fun hints_and_slow_answers_are_weaker_evidence() {
        assertEquals(Grade.AGAIN, SrsEngine.gradeFor(false, 0, QType.MCQ, 1000))
        assertEquals(Grade.HARD, SrsEngine.gradeFor(true, 1, QType.FULL_RECALL, 2000))
        assertEquals(Grade.EASY, SrsEngine.gradeFor(true, 0, QType.FULL_RECALL, 3000))
        assertEquals(Grade.GOOD, SrsEngine.gradeFor(true, 0, QType.MCQ, 2000))
        assertEquals(Grade.HARD, SrsEngine.gradeFor(true, 0, QType.MCQ, 30_000))
    }

    // ---------- mastery ----------
    @Test fun one_correct_answer_is_never_mastery() {
        val p = ProgressEntity("NO", stage = 5, correct = 1, streak = 1, intervalDays = 1.0, spacedSuccesses = 0)
        assertNotEquals(Mastery.MASTERED, Mastery.of(p)); assertNotEquals(Mastery.GOOD, Mastery.of(p))
    }

    @Test fun mastery_needs_spaced_successes() {
        val m = ProgressEntity("NO", stage = 5, correct = 9, streak = 9, intervalDays = 16.0, spacedSuccesses = 3)
        assertEquals(Mastery.MASTERED, Mastery.of(m))
        assertEquals(Mastery.WEAK, Mastery.of(m.copy(lastWasWrong = true)))
    }

    // ---------- review uses memory, not randomness ----------
    @Test fun review_pool_prioritises_weak_and_due_and_skips_mastered() {
        val weak = ProgressEntity("NO", stage = 5, correct = 1, wrong = 3, lapses = 3, lastSeen = now - 1000, nextReview = now + 600_000, lastWasWrong = true)
        val due = ProgressEntity("JP", stage = 5, correct = 4, streak = 4, intervalDays = 3.0, spacedSuccesses = 1, lastSeen = now - 4 * DAY, nextReview = now - DAY)
        val mastered = ProgressEntity("EG", stage = 5, correct = 12, streak = 12, intervalDays = 40.0, spacedSuccesses = 4, lastSeen = now - 5 * DAY, nextReview = now + 35 * DAY)
        val fresh = ProgressEntity("FR")
        val pool = SrsEngine.reviewCandidates(listOf(mastered, fresh, due, weak), now)
        assertEquals(listOf("NO", "JP"), pool.map { it.code })      // weak first, mastered/not-due excluded
    }

    // ---------- answer matching ----------
    @Test fun matcher_handles_punctuation_diacritics_and_typos() {
        val known = QuestionGenerator.known(countries())
        fun m(i: String, vararg a: String) = AnswerMatcher.check(i, a.toList(), known)
        assertEquals(Match.EXACT, m("washington dc", "Washington, D.C.", "Washington"))
        assertEquals(Match.EXACT, m("Bogota", "Bogotá"))
        assertEquals(Match.EXACT, m("saint johns", "St. John's"))
        assertEquals(Match.TYPO, m("Ouagadogou", "Ouagadougou"))
        assertEquals(Match.WRONG, m("Kingston", "Kingstown"))      // another country's real capital is never a "typo"
        assertEquals(Match.WRONG, m("Sydney", "Canberra"))
    }

    // ---------- question generation ----------
    @Test fun mcq_choices_are_logical_unique_and_contain_the_answer() {
        val all = countries(); val no = all.first { it.code == "NO" }
        repeat(20) {
            val ch = QuestionGenerator.choices(no, all, listOf("Stockholm"), Random(it))
            assertEquals(4, ch.toSet().size); assertTrue("Oslo" in ch)
            val byCap = all.associateBy { it.capital }
            assertTrue("distractors should come from the same continent", ch.filter { it != "Oslo" }.all { byCap[it]?.continent == "Europe" })
        }
        val sa = all.first { it.code == "ZA" }
        repeat(20) { assertFalse("Cape Town" in QuestionGenerator.choices(sa, all, emptyList(), Random(it)) .filter { c -> c != "Pretoria" }) }
    }

    @Test fun journey_unlocks_next_continent_after_80_percent() {
        val c = countries()
        val none = Journey.states(c, emptyList(), false)
        assertTrue(none[0].unlocked); assertFalse(none[1].unlocked)
        val africa = c.filter { it.continent == "Africa" }.take(44).map { ProgressEntity(it.code, stage = 5) }   // 44/54 = 81%
        assertTrue(Journey.states(c, africa, false)[1].unlocked)
    }
}
