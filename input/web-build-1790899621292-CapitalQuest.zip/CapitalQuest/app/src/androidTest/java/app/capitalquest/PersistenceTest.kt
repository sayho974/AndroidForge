package app.capitalquest

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import app.capitalquest.data.AnswerInput
import app.capitalquest.data.AppDatabase
import app.capitalquest.data.Repository
import app.capitalquest.domain.*
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Your acceptance checklist, run against a REAL on-disk Room database with a simulated app restart. */
@RunWith(AndroidJUnit4::class)
class PersistenceTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()
    private val name = "persistence-test.db"
    private val DAY = SrsEngine.DAY_MS

    private fun open() = Room.databaseBuilder(ctx, AppDatabase::class.java, name).build()
    @Before fun clean() { ctx.deleteDatabase(name) }
    @After fun tearDown() { ctx.deleteDatabase(name) }

    private fun ans(code: String, ok: Boolean, journey: Boolean, t: Long = 4000) =
        AnswerInput(code, if (journey) QType.MCQ else QType.FULL_RECALL, "x", ok, 0, t, journey, !journey, "s")

    @Test fun progress_survives_restart_and_review_reacts_to_memory() = runBlocking {
        var db = open(); var repo = Repository(db, ctx); repo.ensureSeeded()
        assertEquals(197, repo.countries.size)
        val t0 = 1_700_000_000_000L

        // 1-5: learn Norway, answer correctly, "close the app", reopen
        repo.markIntroduced("NO", t0)
        repo.submitAnswer(ans("NO", true, true), t0 + 1000)
        db.close(); db = open(); repo = Repository(db, ctx); repo.ensureSeeded()
        assertEquals(2, repo.progressOf("NO").stage)
        assertEquals(1, repo.progressOf("NO").correct)

        // 6-7: wrong several times -> becomes a review priority
        repeat(3) { repo.submitAnswer(ans("NO", false, false), t0 + 5000L + it) }
        val p = repo.progressOf("NO")
        assertEquals(Mastery.WEAK, Mastery.of(p))
        assertTrue(SrsEngine.reviewCandidates(repo.allProgress(), t0 + 20 * 60_000).any { it.code == "NO" })

        // 8-9: correct several times on different days -> interval changes and grows
        var now = t0 + DAY; var last = repo.progressOf("NO").intervalDays; var grew = 0
        repeat(4) { repo.submitAnswer(ans("NO", true, false), now); val i = repo.progressOf("NO").intervalDays; if (i > last) grew++; last = i; now += (last * DAY).toLong() + 1 }
        assertTrue(grew >= 3); assertTrue(last > 5)

        // 10-11: mastered-looking country is not due until its interval passes; review pool is memory based
        val soon = repo.progressOf("NO").lastSeen + DAY
        assertFalse(SrsEngine.reviewCandidates(repo.allProgress(), soon).any { it.code == "NO" && !SrsEngine.isProblem(it) })
        db.close()
    }
}
