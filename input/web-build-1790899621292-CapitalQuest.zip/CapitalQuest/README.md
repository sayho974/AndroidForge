# Capital Quest 🌍 — تطبيق Android أصلي (Kotlin + Jetpack Compose + Room)

Offline بالكامل (لا يوجد صلاحية INTERNET في الـ Manifest). كل إجابة تُحفظ فورًا في قاعدة SQLite داخل الجهاز.

## البنية
| الطبقة | الملفات |
|---|---|
| Local DB | `data/Entities.kt`, `Daos.kt`, `AppDatabase.kt` (Room) |
| Offline Data | `assets/countries.csv` (197 دولة) + `data/CountryCsv.kt` |
| Spaced Repetition Engine | `domain/SrsEngine.kt` (SM-2 معدّل) + `Models.kt` (Mastery) |
| Question Generator | `domain/QuestionGenerator.kt`, `AnswerMatcher.kt` (تلميحات + مطابقة ذكية) |
| Progress System | `data/Repository.kt` (معاملة واحدة لكل إجابة: تقدم + XP + Streak + إنجازات), `domain/Journey.kt`, `Achievements.kt` |
| UI | `ui/*` (Compose) + `tts/Speaker.kt` |

## البناء
- **GitHub Actions (الأسهل من الموبايل):** ارفع المجلد كله على مستودع GitHub → تبويب Actions → "Build APK" → حمّل `CapitalQuest-debug-apk`. الـ workflow يشغّل الاختبارات أولًا ثم يبني الـ APK.
- **Android Studio:** افتح المجلد → Run. (Gradle 8.9 / JDK 17)

## الاختبارات
- `./gradlew testDebugUnitTest` : الداتا (197 دولة)، خوارزمية التكرار، الإتقان، اختيار المراجعة، المطابقة، الاختيارات.
- `./gradlew connectedDebugAndroidTest` : اختبار على جهاز/محاكي يحاكي قائمتك: تعلّم → إجابة → إغلاق وفتح → أخطاء → أولوية مراجعة → تغيّر الموعد.

## ملاحظات تصميم
- الدولة "متقنة" فقط بعد 3 مراجعات ناجحة متباعدة (≥18 ساعة) وفاصل ≥14 يوم. الإتقان الأول عمليًا بعد ~4 أسابيع.
- الإجابة بتلميح تُسجَّل كـ HARD (أضعف من الاسترجاع الذاتي).
- الحالات الخاصة (جنوب أفريقيا، بوليفيا، هولندا، سريلانكا، إلخ) تقبل كل العواصم الرسمية ويظهر شرحها.
- لتحديث الداتا: عدّل `countries.csv` وارفع `CountryCsv.SEED_VERSION` (التقدم لا يُمسح).
- لا تستخدم `fallbackToDestructiveMigration()` أبدًا؛ اكتب Migration عند تغيير الـ schema.
